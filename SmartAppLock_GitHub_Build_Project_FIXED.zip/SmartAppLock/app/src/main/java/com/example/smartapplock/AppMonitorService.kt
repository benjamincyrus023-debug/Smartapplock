package com.example.smartapplock

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class AppMonitorService : AccessibilityService() {
    private var lastPackage: String? = null
    private var lastLaunchTime = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return

        // A new foreground app ends the temporary unlock session for the previous app.
        if (pkg != lastPackage) {
            SecurityStore.setTemporarilyUnlocked(this, null)
            lastPackage = pkg
        }

        if (pkg !in SecurityStore.selected(this)) return
        if (SecurityStore.temporarilyUnlocked(this) == pkg) return

        val now = System.currentTimeMillis()
        if (now - lastLaunchTime < 1500L) return
        lastLaunchTime = now

        startActivity(Intent(this, LockActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra(LockActivity.EXTRA_TARGET_PACKAGE, pkg)
        })
    }

    override fun onInterrupt() {
        lastPackage = null
    }
}
