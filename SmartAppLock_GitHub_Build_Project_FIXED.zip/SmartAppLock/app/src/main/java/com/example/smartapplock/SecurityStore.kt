package com.example.smartapplock

import android.content.Context
import android.util.Base64
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

object SecurityStore {
    private const val PREFS = "smart_lock_prefs"
    private const val SALT = "pin_salt"
    private const val HASH = "pin_hash"
    private const val SELECTED = "selected_packages"
    private const val UNLOCKED_PACKAGE = "temporarily_unlocked_package"
    private const val ITERATIONS = 120_000

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun hasPin(context: Context): Boolean = prefs(context).contains(HASH)

    fun setPin(context: Context, pin: String) {
        require(pin.length in 4..6 && pin.all(Char::isDigit))
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val hash = derive(pin, salt)
        prefs(context).edit()
            .putString(SALT, Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString(HASH, Base64.encodeToString(hash, Base64.NO_WRAP))
            .apply()
    }

    fun verifyPin(context: Context, pin: String): Boolean {
        val p = prefs(context)
        val saltText = p.getString(SALT, null) ?: return false
        val hashText = p.getString(HASH, null) ?: return false
        return try {
            val salt = Base64.decode(saltText, Base64.NO_WRAP)
            val expected = Base64.decode(hashText, Base64.NO_WRAP)
            val actual = derive(pin, salt)
            java.security.MessageDigest.isEqual(expected, actual)
        } catch (_: Exception) { false }
    }

    private fun derive(pin: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), salt, ITERATIONS, 256)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(spec).encoded
    }

    fun selected(context: Context): Set<String> =
        prefs(context).getStringSet(SELECTED, emptySet())?.toSet() ?: emptySet()

    fun setSelected(context: Context, packages: Set<String>) {
        prefs(context).edit().putStringSet(SELECTED, packages.toSet()).apply()
    }

    fun temporarilyUnlock(context: Context, packageName: String) {
        prefs(context).edit().putString(UNLOCKED_PACKAGE, packageName).apply()
    }

    fun temporarilyUnlocked(context: Context): String? =
        prefs(context).getString(UNLOCKED_PACKAGE, null)

    fun clearTemporaryUnlock(context: Context) {
        prefs(context).edit().remove(UNLOCKED_PACKAGE).apply()
    }

    fun setTemporarilyUnlocked(context: Context, packageName: String?) {
        prefs(context).edit().putString(UNLOCKED_PACKAGE, packageName).apply()
    }

}
