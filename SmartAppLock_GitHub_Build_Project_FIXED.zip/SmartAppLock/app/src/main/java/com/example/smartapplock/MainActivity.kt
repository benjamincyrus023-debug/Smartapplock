package com.example.smartapplock

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

val Navy = Color(0xFF123B70)
val Blue = Color(0xFF2478E5)

data class LaunchableApp(val label: String, val packageName: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        appsContextHolder.context = this
        setContent {
            var pinIsSet by remember { mutableStateOf(SecurityStore.hasPin(this)) }
            MaterialTheme(colorScheme = lightColorScheme(
                primary = Blue, secondary = Navy, background = Color(0xFFF4F7FC)
            )) {
                Surface(Modifier.fillMaxSize(), color = Color(0xFFF4F7FC)) {
                    AppHome(
                        hasPin = pinIsSet,
                        apps = remember { loadApps() },
                        selected = remember { mutableStateOf(SecurityStore.selected(this)) },
                        onSavePin = { SecurityStore.setPin(this, it); pinIsSet = true },
                        onMonitoring = {
                            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        }
                    )
                }
            }
        }
    }

    private fun loadApps(): List<LaunchableApp> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, 0)
            .mapNotNull {
                val pkg = it.activityInfo.packageName
                if (pkg == packageName) null
                else LaunchableApp(it.loadLabel(packageManager).toString(), pkg)
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }
}

@Composable
fun AppHome(
    hasPin: Boolean,
    apps: List<LaunchableApp>,
    selected: MutableState<Set<String>>,
    onSavePin: (String) -> Unit,
    onMonitoring: () -> Unit
) {
    var pin by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Lock, null, tint = Blue, modifier = Modifier.size(34.dp))
            Spacer(Modifier.width(10.dp))
            Column {
                Text("Smart AppLock", style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold, color = Navy)
                Text("Your apps. Your privacy.", color = Color.Gray)
            }
        }
        Spacer(Modifier.height(20.dp))

        if (!hasPin) {
            Card(shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Create your security PIN", fontWeight = FontWeight.Bold)
                    OutlinedTextField(pin, { pin = it.filter(Char::isDigit).take(6) },
                        label = { Text("4–6 digit PIN") })
                    OutlinedTextField(confirm, { confirm = it.filter(Char::isDigit).take(6) },
                        label = { Text("Confirm PIN") })
                    Button(onClick = {
                        if (pin.length in 4..6 && pin == confirm) {
                            onSavePin(pin)
                            message = "PIN saved. Select apps below."
                        } else message = "PINs must match and contain 4–6 digits."
                    }) { Text("Save PIN") }
                    Text(message, color = Blue)
                }
            }
        } else {
            Text("Protection dashboard", style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold, color = Navy)
            Text("${selected.value.size} apps selected for protection")
            Spacer(Modifier.height(8.dp))
            Button(onClick = onMonitoring, modifier = Modifier.fillMaxWidth()) {
                Text("Enable app monitoring in Android settings")
            }
            Text("You must manually enable the Smart AppLock accessibility service.",
                style = MaterialTheme.typography.bodySmall, color = Color.Gray)
            Spacer(Modifier.height(12.dp))
            Text("Choose apps to protect", fontWeight = FontWeight.Bold)
            LazyColumn(Modifier.weight(1f)) {
                items(apps, key = { it.packageName }) { app ->
                    val checked = app.packageName in selected.value
                    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(app.label, fontWeight = FontWeight.Medium)
                            Text(app.packageName, style = MaterialTheme.typography.labelSmall,
                                color = Color.Gray)
                        }
                        Switch(checked = checked, onCheckedChange = { enabled ->
                            val next = selected.value.toMutableSet()
                            if (enabled) next.add(app.packageName) else next.remove(app.packageName)
                            selected.value = next
                            SecurityStore.setSelected(appsContextHolder.context, next)
                        })
                    }
                    HorizontalDivider()
                }
            }
        }
    }
}

// Context is assigned by the Activity before the Compose screen is displayed.
object appsContextHolder { lateinit var context: android.content.Context }
