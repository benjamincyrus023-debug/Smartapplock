# Build the APK from your phone using GitHub Actions

1. Create a new **public** GitHub repository named `SmartAppLock` (public repositories allow GitHub Actions usage without using private-repository minutes; GitHub limits and policies may change).
2. Upload `SmartAppLock_AndroidStudio_Project.zip` to the repository root.
3. In the repository, choose **Add file → Create new file**.
4. Enter this exact filename: `.github/workflows/build-apk.yml`
5. Paste the workflow content from the included `.github/workflows/build-apk.yml` file, then commit it to the `main` branch.
6. Open the **Actions** tab. Select **Build Smart AppLock APK**, then **Run workflow** if it has not started automatically.
7. Wait for the run to finish successfully. Open the run, scroll to **Artifacts**, and download `SmartAppLock-debug-apk`.
8. Extract the downloaded artifact ZIP on your phone. Install `app-debug.apk`, allowing installs from your browser/files app if Android asks.

If the workflow fails, open the run and copy the first red error section so it can be diagnosed.

Security note: this is a development/debug APK, not a Play Store release. Android 15 and TECNO HiOS may restrict AccessibilityService-triggered overlays/background activity starts. Real-device testing is essential. The service is intended to observe window changes only; it does not retrieve screen contents. Clearly explain the service and request explicit user consent before enabling it.
