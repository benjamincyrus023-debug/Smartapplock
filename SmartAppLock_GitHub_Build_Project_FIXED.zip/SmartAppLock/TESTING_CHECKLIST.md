# Smart AppLock device testing checklist

A successful Gradle build has not yet been verified in this environment because Android SDK/Gradle are not installed here. Use Android Studio and a physical Android 10–16 device for the following checks.

## Build checks
- [ ] Open this folder in Android Studio and allow Gradle sync.
- [ ] Install Android SDK Platform 35 and use JDK 17.
- [ ] Build > Make Project; resolve any SDK/plugin prompts.
- [ ] Run on a physical Android device (emulator biometric support varies).

## Functional checks
- [ ] Create a 4-digit PIN and verify the dashboard appears.
- [ ] Force-stop/reopen Smart AppLock and confirm PIN remains configured.
- [ ] Select a test app, enable Smart AppLock under Android Accessibility settings.
- [ ] Open the selected app; confirm the PIN screen appears.
- [ ] Enter a wrong PIN; confirm access is not granted.
- [ ] Enter the correct PIN; confirm the selected app opens.
- [ ] Switch to another app and return; confirm it asks for the PIN again.
- [ ] Test biometric prompt on a device with enrolled biometrics.
- [ ] Test after reboot, battery optimization, and manufacturer-specific background restrictions.
- [ ] Test Android 10, 11, 12, 13, 14, 15, and 16 where available.

## Known prototype limitations
- This is a starter prototype, not a production-hardened security product.
- AccessibilityService must be explicitly enabled by the device owner. Its behaviour and background activity launching vary across Android versions and manufacturers.
- The sample stores a temporary unlocked-package marker in app preferences; a production version should use a more robust foreground-session design and harden storage/rate limiting.
- Add a secure PIN recovery flow, lockout policy, privacy disclosure, accessibility policy review, and broader QA before distribution.
