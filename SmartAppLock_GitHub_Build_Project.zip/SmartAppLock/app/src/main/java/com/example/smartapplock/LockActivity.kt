package com.example.smartapplock

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class LockActivity : ComponentActivity() {
    companion object { const val EXTRA_TARGET_PACKAGE = "target_package" }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // Keep the lock screen visible until authentication succeeds.
            }
        })
        setContent {
            var pin by remember { mutableStateOf("") }
            var error by remember { mutableStateOf("") }
            MaterialTheme(colorScheme = lightColorScheme(primary = Blue)) {
                Surface(Modifier.fillMaxSize(), color = Navy) {
                    Column(Modifier.fillMaxSize().padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center) {
                        Text("App protected", color = androidx.compose.ui.graphics.Color.White,
                            style = MaterialTheme.typography.headlineMedium)
                        Spacer(Modifier.height(20.dp))
                        OutlinedTextField(value = pin, onValueChange = {
                            pin = it.filter(Char::isDigit).take(6)
                        }, label = { Text("Enter PIN") })
                        Button(onClick = {
                            if (SecurityStore.verifyPin(this@LockActivity, pin)) {
                                SecurityStore.setTemporarilyUnlocked(
                                    this@LockActivity,
                                    intent.getStringExtra(EXTRA_TARGET_PACKAGE)
                                )
                                finish()
                            } else { error = "Incorrect PIN"; pin = "" }
                        }) { Text("Unlock") }
                        Text(error, color = androidx.compose.ui.graphics.Color.White)
                        TextButton(onClick = { showBiometric() }) {
                            Text("Use fingerprint", color = androidx.compose.ui.graphics.Color.White)
                        }
                    }
                }
            }
        }
    }

    private fun showBiometric() {
        val manager = BiometricManager.from(this)
        if (manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG)
            != BiometricManager.BIOMETRIC_SUCCESS) return

        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    SecurityStore.setTemporarilyUnlocked(
                        this@LockActivity,
                        intent.getStringExtra(EXTRA_TARGET_PACKAGE)
                    )
                    intent.getStringExtra(EXTRA_TARGET_PACKAGE)?.let {
                        SecurityStore.temporarilyUnlock(this@LockActivity, it)
                    }
                    finish()
                }
            })
        prompt.authenticate(BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock Smart AppLock")
            .setSubtitle("Verify your identity")
            .setNegativeButtonText("Use PIN")
            .build())
    }
}
